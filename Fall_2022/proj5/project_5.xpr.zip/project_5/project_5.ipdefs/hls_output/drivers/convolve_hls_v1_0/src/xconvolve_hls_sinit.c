// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xconvolve_hls.h"

extern XConvolve_hls_Config XConvolve_hls_ConfigTable[];

XConvolve_hls_Config *XConvolve_hls_LookupConfig(u16 DeviceId) {
	XConvolve_hls_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCONVOLVE_HLS_NUM_INSTANCES; Index++) {
		if (XConvolve_hls_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XConvolve_hls_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XConvolve_hls_Initialize(XConvolve_hls *InstancePtr, u16 DeviceId) {
	XConvolve_hls_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XConvolve_hls_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XConvolve_hls_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

